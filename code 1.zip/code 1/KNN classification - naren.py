#!/usr/bin/env python
# coding: utf-8

# In[1]:


import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns
import sklearn as sk


from sklearn.model_selection import train_test_split


# In[2]:


df = pd.read_csv('bank-full.csv')


# In[3]:


df.shape


# In[4]:


df.info()


# In[5]:


df.isna().sum()


# In[6]:


df['y'] = df['y'].apply(lambda y: 1 if y == 'yes' else 0)


# In[7]:


df


# In[8]:


df.select_dtypes('object')


# In[9]:


{column: list(df[column].unique()) for column in df.select_dtypes('object').columns}


# In[10]:


categorical_features=[feature for feature in df.columns if ((df[feature].dtypes=='O') & (feature not in ['y']))]
categorical_features
    


# In[11]:


for feature in categorical_features:
    print('The feature is {} and number of categories are {}'.format(feature,len(df[feature].unique())))


# In[12]:


plt.figure(figsize=(15,80), facecolor='white')
plotnumber =1
for categorical_feature in categorical_features:
    ax = plt.subplot(12,3,plotnumber)
    sns.countplot(y=categorical_feature,data=df)
    plt.xlabel(categorical_feature)
    plt.title(categorical_feature)
    plotnumber+=1
plt.show()


# In[13]:


for categorical_feature in categorical_features:
    sns.catplot(x='y', col=categorical_feature, kind='count', data= df)
plt.show()


# In[14]:


dataset = df.drop(['duration','day','campaign','pdays', 'previous'], axis = 1)


# In[15]:


dataset


# In[16]:


x = dataset.iloc[:, 0:10].values
y = dataset.iloc[:, 11].values


# In[17]:



from sklearn.preprocessing import OneHotEncoder,LabelEncoder


# In[18]:


enc_onehot = OneHotEncoder()

x=enc_onehot.fit_transform(dataset[['job','default','contact','marital','education', 'housing', 'loan','month']]).toarray()


# In[19]:


enc_label = LabelEncoder()

y = enc_label.fit_transform(dataset['y'])


# In[20]:


from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size = 0.2, random_state = 0)


# In[21]:


from sklearn.preprocessing import StandardScaler
sc=StandardScaler()
x_train_s=sc.fit_transform(x_train)
x_test_s=sc.transform(x_test)


# In[23]:


from sklearn.neighbors import KNeighborsClassifier
classifier=KNeighborsClassifier(n_neighbors=5,metric='minkowski',p=2)
classifier.fit(x_train_s,y_train)


# In[24]:


y_pred=classifier.predict(x_test_s)
print(y_pred)


# In[28]:


print(y_test)


# In[25]:


from sklearn import metrics
acc=metrics.accuracy_score(y_test,y_pred)
print('accuracy:%.2f\n\n'%(acc))
cm=metrics.confusion_matrix(y_test,y_pred)
print('confusion Matrix:')
print(cm,'\n\n')
print('--------------------')
result=metrics.classification_report(y_test,y_pred)
print('classification')
print(result)


# In[26]:


from sklearn.metrics import plot_confusion_matrix


# In[27]:


ax = sns.heatmap(cm, cmap = 'BuPu',  annot=True, fmt='d')
                 
plt.xlabel("Predicted Class", fontsize=12)
plt.ylabel("True Class", fontsize=12)
plt.title("Confusion Matrix", fontsize=12)    
                 
plt.show()


# In[ ]:




