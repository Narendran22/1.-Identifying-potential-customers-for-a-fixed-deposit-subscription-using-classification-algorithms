#!/usr/bin/env python
# coding: utf-8

# In[28]:


import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns
import sklearn as sk


from sklearn.model_selection import train_test_split


# In[29]:


df = pd.read_csv('bank-full.csv')


# In[30]:


df.shape


# In[31]:


df.info()


# In[32]:


df.isna().sum()


# In[33]:


df['y'] = df['y'].apply(lambda y: 1 if y == 'yes' else 0)


# In[34]:


df


# In[35]:


df.select_dtypes('object')


# In[36]:


{column: list(df[column].unique()) for column in df.select_dtypes('object').columns}


# In[37]:


df.isna().sum()


# In[38]:


categorical_features=[feature for feature in df.columns if ((df[feature].dtypes=='O') & (feature not in ['y']))]
categorical_features
    


# In[39]:


for feature in categorical_features:
    print('The feature is {} and number of categories are {}'.format(feature,len(df[feature].unique())))


# In[40]:


plt.figure(figsize=(15,80), facecolor='white')
plotnumber =1
for categorical_feature in categorical_features:
    ax = plt.subplot(12,3,plotnumber)
    sns.countplot(y=categorical_feature,data=df)
    plt.xlabel(categorical_feature)
    plt.title(categorical_feature)
    plotnumber+=1
plt.show()


# In[41]:


for categorical_feature in categorical_features:
    sns.catplot(x='y', col=categorical_feature, kind='count', data= df)
plt.show()


# In[42]:


for categorical_feature in categorical_features:
    print(df.groupby(['y',categorical_feature]).size())


# In[43]:


dataset = df.drop(['duration','day','campaign','pdays', 'previous'], axis = 1)


# In[44]:


dataset


# In[45]:


x = dataset.iloc[:, 0:10].values
y = dataset.iloc[:, 11].values


# In[56]:



from sklearn.preprocessing import OneHotEncoder


# In[47]:


enc_onehot = OneHotEncoder()

x=enc_onehot.fit_transform(dataset[['job','default','contact','marital','education', 'housing', 'loan','month']]).toarray()
  


# In[48]:


from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size = 0.2, random_state = 0)


# In[49]:


from sklearn.preprocessing import StandardScaler
sc=StandardScaler()
x_train_s=sc.fit_transform(x_train)
x_test_s=sc.transform(x_test)


# In[50]:


from sklearn.tree import DecisionTreeClassifier
classifier = DecisionTreeClassifier(criterion = 'entropy', random_state = 0)
classifier.fit(x_train_s, y_train)


# In[51]:


y_pred=classifier.predict(x_test_s)
print(y_pred)


# In[57]:


print(y_test)


# In[55]:


from sklearn import metrics
acc=metrics.accuracy_score(y_test,y_pred)
print('accuracy:%.2f\n\n'%(acc))
cm=metrics.confusion_matrix(y_test,y_pred)
print('Confusion Matrix:')
print(cm,'\n\n')
print('-----------------------------------------------------')
result=metrics.classification_report(y_test,y_pred)
print('Classification Report:\n')
print(result)


# In[53]:


from sklearn.metrics import plot_confusion_matrix


# In[54]:


ax = sns.heatmap(cm, cmap = 'BuPu',  annot=True, fmt='d')
                 
plt.xlabel("Predicted Class", fontsize=12)
plt.ylabel("True Class", fontsize=12)
plt.title("Confusion Matrix", fontsize=12)    
                 
plt.show()


# In[ ]:




